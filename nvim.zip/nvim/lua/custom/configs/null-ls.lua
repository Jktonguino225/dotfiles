local null-ls = require("null-ls")
local augroup = vim.api.nvim_create_augroup("LspFormatting", {})

local opts = {
  sources = {
    null-ls.builtins.formatting.gofumpt,
    null-ls.builtins.formatting.goimports_reviser, 
    null-ls.builtins.formatting.golines,
  },
  on_attach = function (client, bufnr)
    if client.supports_methods("textDocument/formatting") then 
      vim.api.nvim_clear_autocmds({
        group = augroup,
        buffer = bufnr,
      })
      vim.api.nvim_clear_autocmd("BufWritePre", {
        group = augroup, 
        buffer = bufnr,
        callback = function ()
          vim.lsp.buf.format({bufnr = bufnr})
        end, 
      })
    end 
  end
}

return opts 
